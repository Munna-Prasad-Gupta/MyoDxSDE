import express from "express";
import {FetchDataStats,FetchDataUsers} from "../controllers/FetchDataControl.js";


const router = express.Router();

router.get('/data/stats',FetchDataStats);
router.get('/data/users',FetchDataUsers);

export default router;