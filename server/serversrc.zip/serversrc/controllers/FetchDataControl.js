// import User from '../models/User.js';
// import Feedback from '../models/FeedbackModel.js';
// import Diagnosis from '../models/Diagnosis.js';




// export const FetchDataStats = async (req, res) => {
//   try {
//     console.log("Came in FetchDataControl.js");

//     const usersCount = await User.countDocuments();
//     const feedbackCount = await Feedback.countDocuments();
//     const diagnosisCount = await Diagnosis.countDocuments();

//     // Dates for weekly analysis
//     const today = new Date();
//     const pastFourWeeks = [];

//     for (let i = 3; i >= 0; i--) {
//       const startOfWeek = new Date(today);
//       startOfWeek.setDate(today.getDate() - today.getDay() - (i * 7));
//       startOfWeek.setHours(0, 0, 0, 0);

//       const endOfWeek = new Date(startOfWeek);
//       endOfWeek.setDate(startOfWeek.getDate() + 6);
//       endOfWeek.setHours(23, 59, 59, 999);

//       pastFourWeeks.push({ start: startOfWeek, end: endOfWeek });
//     }

//     // Get weekly user counts
//     const userGrowth = await Promise.all(
//       pastFourWeeks.map(async ({ start, end }) => {
//         const count = await User.countDocuments({
//           createdAt: { $gte: start, $lte: end },
//         });
//         return count;
//       })
//     );

//     // New users this week
//     const { start: startOfThisWeek, end: endOfThisWeek } = pastFourWeeks[3];
//     const newUsersThisWeek = await User.countDocuments({
//       createdAt: { $gte: startOfThisWeek, $lte: endOfThisWeek },
//     });

// //     const recentFeedbacks = await Feedback.find({})
// //   .sort({ createdAt: -1 })
// //   .limit(4)
// //   .select('feedback.satisfaction feedback.easeOfUse feedback.clarity feedback.helpfulness feedback.suggestions');

// // res.status(200).json({
// //   users: usersCount,
// //   feedback: feedbackCount,
// //   diagnoses: diagnosisCount,
// //   newUsersThisWeek,
// //   userGrowth,
// //   recentFeedbacks: recentFeedbacks.map(fb => ({
// //     satisfaction: fb.feedback.satisfaction,
// //     easeOfUse: fb.feedback.easeOfUse,
// //     clarity: fb.feedback.clarity,
// //     helpfulness: fb.feedback.helpfulness,
// //     suggestions: fb.feedback.suggestions
// //   }))
// // });

// const recentFeedbacks = await Feedback.find({})
//   .sort({ createdAt: -1 })
//   .limit(4)
//   .select('feedback.satisfaction feedback.easeOfUse feedback.clarity feedback.helpfulness feedback.suggestions userId') // Include userId to fetch the name
//   .populate('userId', 'name'); // Populate the name from the User model

// res.status(200).json({
//   users: usersCount,
//   feedback: feedbackCount,
//   diagnoses: diagnosisCount,
//   newUsersThisWeek,
//   userGrowth,
//   recentFeedbacks: recentFeedbacks.map(fb => ({
//     satisfaction: fb.feedback.satisfaction,
//     easeOfUse: fb.feedback.easeOfUse,
//     clarity: fb.feedback.clarity,
//     helpfulness: fb.feedback.helpfulness,
//     suggestions: fb.feedback.suggestions,
//     feedbackGiverName: fb.userId.name // Adding feedback giver's name
//   }))
// });



//   } catch (error) {
//     console.error('Error fetching stats:', error);
//     res.status(500).json({ message: 'Server error' });
//   }
// };




import User from '../models/User.js';
import Feedback from '../models/FeedbackModel.js';
import Diagnosis from '../models/Diagnosis.js';

export const FetchDataStats = async (req, res) => {
  try {
    console.log("Came in FetchDataControl.js");

    const usersCount = await User.countDocuments();
    const feedbackCount = await Feedback.countDocuments();
    const diagnosisCount = await Diagnosis.countDocuments();

    // Dates for weekly analysis
    const today = new Date();
    const pastFourWeeks = [];

    for (let i = 3; i >= 0; i--) {
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - today.getDay() - (i * 7));
      startOfWeek.setHours(0, 0, 0, 0);

      const endOfWeek = new Date(startOfWeek);
      endOfWeek.setDate(startOfWeek.getDate() + 6);
      endOfWeek.setHours(23, 59, 59, 999);

      pastFourWeeks.push({ start: startOfWeek, end: endOfWeek });
    }

    // Get weekly user counts
    const userGrowth = await Promise.all(
      pastFourWeeks.map(async ({ start, end }) => {
        const count = await User.countDocuments({
          createdAt: { $gte: start, $lte: end },
        });
        return count;
      })
    );

    // New users this week
    const { start: startOfThisWeek, end: endOfThisWeek } = pastFourWeeks[3];
    const newUsersThisWeek = await User.countDocuments({
      createdAt: { $gte: startOfThisWeek, $lte: endOfThisWeek },
    });

    // Fetch recent feedbacks with feedback giver's name
    const recentFeedbacks = await Feedback.find({})
      .sort({ createdAt: -1 })
      .limit(4)
      .select('feedback.satisfaction feedback.easeOfUse feedback.clarity feedback.helpfulness feedback.suggestions userId') // Include userId to fetch the name
      .populate('userId', 'name'); // Populate the name from the User model

      // console.log(recentFeedbacks);

    res.status(200).json({
      users: usersCount,
      feedback: feedbackCount,
      diagnoses: diagnosisCount,
      newUsersThisWeek,
      userGrowth,
      recentFeedbacks: recentFeedbacks.map(fb => ({
        satisfaction: fb.feedback.satisfaction,
        easeOfUse: fb.feedback.easeOfUse,
        clarity: fb.feedback.clarity,
        helpfulness: fb.feedback.helpfulness,
        suggestions: fb.feedback.suggestions,
        feedbackGiverName: fb.userId ? fb.userId.name : 'Unknown' // Safely adding the feedback giver's name
      }))
    });
    
  } catch (error) {
    console.error('Error fetching stats:', error);
    res.status(500).json({ message: 'Server error' });
  }
};



export const FetchDataUsers = async (req, res) => {
  try {
    // Fetch all users from the database
    const users = await User.find();

    // Return the users data
    res.status(200).json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
